/* May only be included by devicetree.h */

